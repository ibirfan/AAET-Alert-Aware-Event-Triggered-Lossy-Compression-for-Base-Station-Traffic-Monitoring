"""Consolidated original and validation traffic monitoring experiments.
Validation seeds are fixed before inspecting results. No parameter tuning.
This checks new realizations of the SAME synthetic model, not real-world transfer.
Open in Thonny and press F5. Requires matplotlib only.

This models measurement coding, NOT radio propagation or a full mobile network.
Five smooth profiles and five profiles with rectangular bursts per seed.
Time spacing: 5 minutes; 288 observations per station span one daily grid.
The source is generated once per seed; every method receives identical inputs.

COST MODEL: logical coding bits. Independent station streams and their order,
sample count, 0..100 range, bit depth, and periodic schedules are agreed in advance.
Event streams contain one flag per time step plus b bits per update.
Fixed streams have b bits per scheduled update and no flags.
Headers, station identifiers, byte padding, packet overhead, losses and delay
are excluded. The bit strings below are not packed binary files.
Bit savings use the quantized every-sample baseline at the SAME bit depth.
Alert counts refer to sampled time points, NOT distinct overload episodes.
Alert-aware triggering adds an update when true and held alert statuses disagree.
It sends the same 8-bit quantized load, not a separate true-status bit.
Quantization and format are unchanged; a status mismatch may persist after sending.
Both schemes assume immediate reliable decoding, so the sender can track the receiver.
This is a course modification, not a claim of research novelty.
Final alert rates pool counts over all stations and seeds; per-run rates
are also saved. An alert is load >= 80%, an experimental choice, not a standard.
"""
from pathlib import Path
import csv
import math
import random
import statistics
import sys

# Experiment settings: leave these unchanged for the first run.
BITS = 8
STATIONS = 10
SAMPLES = 288
MINUTES_PER_SAMPLE = 5
PREVIOUS_SEEDS = [11, 22, 33, 44, 55]
SEEDS = [101, 202, 303, 404, 505]
assert set(SEEDS).isdisjoint(PREVIOUS_SEEDS)
METHODS = [
    ("Every sample", "fixed", 1),
    ("Every 2 samples", "fixed", 2),
    ("Every 4 samples", "fixed", 4),
    ("Event threshold 5", "event", 5),
    ("Event threshold 10", "event", 10),
]


def generate_traffic(seed):
    """Declared synthetic model: daily sine trend, noise, optional bursts."""
    rng = random.Random(seed)
    stations = []
    for station in range(STATIONS):
        centre = rng.uniform(40, 55)
        amplitude = rng.uniform(20, 30)
        peak_hour = rng.uniform(13, 19)
        noise_sd = rng.uniform(0.5, 2.0)
        bursts = []
        if station >= STATIONS // 2:
            for _ in range(3):
                start = rng.randrange(24, SAMPLES - 24)
                duration = rng.randrange(3, 13)
                magnitude = rng.uniform(15, 30)
                bursts.append((start, start + duration, magnitude))
        values = []
        for t in range(SAMPLES):
            hour = t * MINUTES_PER_SAMPLE / 60
            load = centre + amplitude * math.cos(2 * math.pi * (hour - peak_hour) / 24)
            load += rng.gauss(0, noise_sd)
            load += sum(size for start, end, size in bursts if start <= t < end)
            values.append(min(100.0, max(0.0, load)))
        stations.append(values)
    return stations


def encode(values, kind, setting, bits=BITS):
    """Return logical bitstream and the encoder's local receiver estimates."""
    step = 100 / (2 ** bits - 1)
    receiver = None
    chunks, reconstructed = [], []
    updates = 0
    for i, actual in enumerate(values):
        if kind == "fixed":
            send = i % setting == 0
        else:
            send = receiver is None or abs(actual - receiver) >= setting
            if kind == "alert_aware" and receiver is not None:
                # OR rule: send for a large load difference OR an alert mismatch.
                status_mismatch = (actual >= ALERT_LEVEL) != (receiver >= ALERT_LEVEL)
                send = send or status_mismatch
            chunks.append("1" if send else "0")
        if send:
            code = round(actual / step)
            chunks.append(format(code, f"0{bits}b"))
            receiver = code * step
            updates += 1
        reconstructed.append(receiver)
    return "".join(chunks), reconstructed, updates


def decode(stream, count, kind, setting, bits=BITS):
    """Decode independently; never access original source measurements."""
    step = 100 / (2 ** bits - 1)
    position = 0
    receiver = None
    values = []
    for i in range(count):
        if kind == "fixed":
            send = i % setting == 0
        else:
            if position >= len(stream) or stream[position] not in "01":
                raise ValueError("Missing or invalid flag")
            send = stream[position] == "1"
            position += 1
        if send:
            code = stream[position:position + bits]
            if len(code) != bits:
                raise ValueError("Truncated code")
            receiver = int(code, 2) * step
            position += bits
        if receiver is None:
            raise ValueError("First sample needs an update")
        values.append(receiver)
    if position != len(stream):
        raise ValueError("Unexpected trailing bits")
    return values


def save_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)



ALERT_LEVEL = 80.0
METHODS += [
    ("Alert-aware threshold 5", "alert_aware", 5),
    ("Alert-aware threshold 10", "alert_aware", 10),
]


def alert_counts(original, reconstructed):
    """Compare each sample's true high-load status with the decoded status."""
    assert len(original) == len(reconstructed)
    counts = dict(tp=0, fn=0, fp=0, tn=0)
    for actual, estimate in zip(original, reconstructed):
        actual_alert = actual >= ALERT_LEVEL
        receiver_alert = estimate >= ALERT_LEVEL
        if actual_alert:
            counts["tp" if receiver_alert else "fn"] += 1
        else:
            counts["fp" if receiver_alert else "tn"] += 1
    return counts


def percent(numerator, denominator):
    # Undefined rates are NaN rather than an invented zero.
    return 100 * numerator / denominator if denominator else float("nan")


def combine(rows):
    totals = {key: sum(r[key] for r in rows) for key in ["tp", "fn", "fp", "tn"]}
    positive = totals["tp"] + totals["fn"]
    negative = totals["fp"] + totals["tn"]
    return dict(**totals, high_load_samples=positive, normal_samples=negative,
                recall_percent=percent(totals["tp"], positive),
                miss_rate_percent=percent(totals["fn"], positive),
                false_positive_rate_percent=percent(totals["fp"], negative),
                precision_percent=percent(totals["tp"], totals["tp"]+totals["fp"]),
                disagreement_percent=percent(totals["fn"]+totals["fp"], positive+negative))


def run_experiment(label):
    output = Path(__file__).resolve().parent / "results" / label
    output.mkdir(parents=True, exist_ok=True)
    details, sample_rows = [], []
    example = None
    for seed in SEEDS:
        sources = generate_traffic(seed)
        if example is None:
            example = sources[-1]
        for station, original in enumerate(sources, start=1):
            profile = "smooth" if station <= STATIONS // 2 else "bursty"
            for name, kind, setting in METHODS:
                stream, estimates, updates = encode(original, kind, setting)
                reconstructed = decode(stream, len(original), kind, setting)
                assert reconstructed == estimates
                assert len(stream) == updates*BITS + (len(original) if kind != "fixed" else 0)
                counts = alert_counts(original, reconstructed)
                assert sum(counts.values()) == len(original)
                mse = sum((x-y)**2 for x,y in zip(original,reconstructed))/len(original)
                details.append(dict(seed=seed, station=station, profile=profile,
                                    method=name, updates=updates, encoded_bits=len(stream),
                                    samples=len(original), mse=mse, **counts))
                for i,(actual,estimate) in enumerate(zip(original,reconstructed)):
                    sample_rows.append(dict(seed=seed, station=station, method=name,
                                            sample=i+1, hour=i*MINUTES_PER_SAMPLE/60,
                                            actual_load=actual, decoded_load=estimate,
                                            actual_alert=int(actual>=ALERT_LEVEL),
                                            receiver_alert=int(estimate>=ALERT_LEVEL)))
    runs = []
    for seed in SEEDS:
        for name,_,_ in METHODS:
            selected=[r for r in details if r["seed"]==seed and r["method"]==name]
            run_bits = sum(r["encoded_bits"] for r in selected)
            run_samples = sum(r["samples"] for r in selected)
            run_rmse = math.sqrt(sum(r["mse"] * r["samples"] for r in selected) / run_samples)
            runs.append(dict(seed=seed, method=name, encoded_bits=run_bits,
                             saving_percent=100*(1-run_bits/(run_samples*BITS)),
                             rmse=run_rmse, **combine(selected)))
    summary=[]
    for name,_,_ in METHODS:
        selected=[r for r in details if r["method"]==name]
        samples=sum(r["samples"] for r in selected)
        total_bits=sum(r["encoded_bits"] for r in selected)
        run_rmses = [math.sqrt(sum(r["mse"] * r["samples"] for r in selected if r["seed"] == seed)
                                  / sum(r["samples"] for r in selected if r["seed"] == seed))
                     for seed in SEEDS]
        summary.append(dict(method=name,mean_bits_per_run=total_bits/len(SEEDS),
                            mean_run_rmse=statistics.mean(run_rmses),
                            sd_run_rmse=statistics.stdev(run_rmses),
                            saving_percent=100*(1-total_bits/(samples*BITS)),
                            **combine(selected)))
    # Source labels must be identical for every reporting method.
    assert len({r["high_load_samples"] for r in summary})==1
    save_csv(output/"station_alert_counts.csv",details)
    save_csv(output/"run_alert_metrics.csv",runs)
    save_csv(output/"alert_summary.csv",summary)
    save_csv(output/"sample_alerts.csv",sample_rows)

    print(f"{label.upper()}: high-load alert when load >= {ALERT_LEVEL:.0f}%")
    print(f"Same {STATIONS} stations x {SAMPLES} samples x {len(SEEDS)} seeds; {BITS}-bit codes.")
    print("Seeds:", SEEDS)
    print("Same model and unchanged rules; no tuning on these results.")
    print("Encoder/decoder, bit-count and confusion-count checks: PASSED")
    print(f"Actual high-load samples: {summary[0]['high_load_samples']:,}")
    print(f"Actual normal-load samples: {summary[0]['normal_samples']:,}")
    print("Counts and alert rates below are pooled over all five runs.\n")
    print(f"{'Method':<26} {'Mean bits':>10} {'RMSE':>7} {'Saving %':>9} {'Missed':>8} {'False':>7} {'Recall %':>10} {'Miss %':>9} {'FPR %':>9}")
    for r in summary:
        print(f"{r['method']:<26} {r['mean_bits_per_run']:>10.1f} {r['mean_run_rmse']:>7.3f} {r['saving_percent']:>9.2f} {r['fn']:>8} {r['fp']:>7} "
              f"{r['recall_percent']:>10.2f} {r['miss_rate_percent']:>9.2f} {r['false_positive_rate_percent']:>9.2f}")
    print("\nMissed = high-load samples incorrectly labelled normal (FN).")
    print("False = normal-load samples incorrectly labelled high (FP).")
    print("Recall = TP/(TP+FN); miss rate = FN/(TP+FN).")
    print("False-positive rate (FPR) = FP/(FP+TN), NOT FP/all raised alerts.")
    print("Counts are sample decisions, not distinct alert episodes.")
    print("Mean bits: total per ten-station run, averaged over five runs.")
    print("RMSE: mean of run-level RMSEs in percentage points.")
    print("Alert-aware rule changes the sender trigger only; the decoder/quantizer are unchanged.")
    print("Each event-format sample has one flag, and each update adds 8 load bits.")
    print("Bit savings use the 8-bit every-sample baseline; headers/padding/network overhead excluded.")
    print("80% is a chosen experimental alert level, not a universal network standard.")
    print("Results apply to this synthetic model; no network control action is simulated.")

    import matplotlib.pyplot as plt
    labels=[r['method'].replace(' samples','\nsamples').replace(' threshold ','\nthreshold ') for r in summary]
    fig,axes=plt.subplots(1,2,figsize=(15,5.5))
    for ax,key,title in zip(axes,["miss_rate_percent","false_positive_rate_percent"],
                            ["Missed high-load samples / all high-load samples", "False alarms / all normal-load samples"]):
        values=[r[key] for r in summary]
        bars=ax.bar(range(len(summary)),values,color=['#64748b','#2563eb','#0891b2','#e87924','#8b5cf6','#16a34a','#db2777'])
        ax.set_xticks(range(len(summary)),labels,fontsize=7)
        ax.set_ylabel("Rate (%) - lower is better")
        ax.set_title(title,fontsize=10)
        ax.set_ylim(0,max(1,max(values))*1.22)
        ax.bar_label(bars,labels=[f"{v:.2f}%" for v in values],padding=3,fontsize=9)
        ax.grid(axis='y',alpha=0.2)
        ax.set_axisbelow(True)
    fig.suptitle(f"{label}: alert errors at {ALERT_LEVEL:.0f}% across five runs")
    fig.tight_layout()
    fig.savefig(output/'alert_error_rates.png',dpi=180)

    # Predetermined illustrative station, not selected for good performance.
    stream,_,_=encode(example,'alert_aware',5)
    estimate=decode(stream,SAMPLES,'alert_aware',5)
    hours=[t*MINUTES_PER_SAMPLE/60 for t in range(SAMPLES)]
    fig2,(ax1,ax2)=plt.subplots(2,1,figsize=(11,6),sharex=True,gridspec_kw={'height_ratios':[3,1]})
    ax1.plot(hours,example,label='Original load',color='tab:blue',linewidth=1.2)
    ax1.step(hours,estimate,where='post',label='Receiver estimate',color='tab:orange',linewidth=1.2)
    ax1.axhline(ALERT_LEVEL,color='black',linestyle=':',label='80% alert level')
    missed=[i for i,(a,b) in enumerate(zip(example,estimate)) if a>=ALERT_LEVEL and b<ALERT_LEVEL]
    false=[i for i,(a,b) in enumerate(zip(example,estimate)) if a<ALERT_LEVEL and b>=ALERT_LEVEL]
    ax1.scatter([hours[i] for i in missed],[example[i] for i in missed],marker='x',color='red',label='Missed alert sample',zorder=4)
    ax1.scatter([hours[i] for i in false],[example[i] for i in false],marker='x',color='purple',label='False alarm sample',zorder=4)
    ax1.set_ylim(0,105)
    ax1.set_ylabel('Load (%)')
    ax1.legend(fontsize=8,loc='upper left')
    ax1.grid(alpha=0.2)
    ax1.set_title(f'Example: seed {SEEDS[0]}, station {STATIONS}, alert-aware threshold 5')
    ax2.step(hours,[int(x>=ALERT_LEVEL) for x in example],where='post',label='Actual alert status',color='tab:blue')
    ax2.step(hours,[int(x>=ALERT_LEVEL) for x in estimate],where='post',label='Receiver alert status',color='tab:orange',linestyle='--')
    ax2.set_yticks([0,1],['Normal','High'])
    ax2.set_ylim(-0.15,1.6)
    ax2.set_xlim(0,24)
    ax2.set_xlabel('Hour (one sample every 5 minutes)')
    ax2.legend(fontsize=8,loc='upper left')
    ax2.grid(alpha=0.2)
    fig2.tight_layout()
    fig2.savefig(output/'alert_example.png',dpi=180)
    print('\nSaved four CSV tables and two graphs in:',output)
    print('Rerunning this script overwrites this experiment group’s result files.')
    if '--no-show' not in sys.argv:
        plt.show()
    else:
        plt.close('all')


def main():
    """Run the original and validation groups with unchanged coding rules."""
    global SEEDS
    for label, seeds in [("original", PREVIOUS_SEEDS), ("validation", [101,202,303,404,505])]:
        SEEDS = seeds
        run_experiment(label)

if __name__ == '__main__':
    main()
